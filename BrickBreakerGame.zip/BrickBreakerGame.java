import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class BrickBreakerGame extends JFrame {
    private boolean gameStarted = false;

    public BrickBreakerGame() {
        setTitle("Brick Breaker");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);

        // Menampilkan halaman awal jika game belum dimulai
        if (!gameStarted) {
            showMainMenu();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BrickBreakerGame::new);
    }

    private void showMainMenu() {
        JPanel mainMenu = new JPanel();
        mainMenu.setLayout(new BorderLayout());
        mainMenu.setBackground(Color.BLACK);

        // Judul Game
        JLabel titleLabel = new JLabel("Brick Breaker", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 40));
        titleLabel.setForeground(Color.WHITE);
        mainMenu.add(titleLabel, BorderLayout.NORTH);

        // Tombol Start
        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.setBackground(Color.BLACK);
        startButton.setForeground(Color.WHITE);
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameStarted = true;
                // Menghilangkan menu utama dan menampilkan game
                getContentPane().removeAll();
                add(new GamePanel());
                revalidate();
                repaint();
            }
        });
        mainMenu.add(startButton, BorderLayout.CENTER);

        // Instruksi di bawah
        JLabel instructions = new JLabel("gunakan panah kiri dan kanan untuk menggerakan papan.", JLabel.CENTER);
        instructions.setFont(new Font("Arial", Font.PLAIN, 20));
        instructions.setForeground(Color.WHITE);
        mainMenu.add(instructions, BorderLayout.SOUTH);

        add(mainMenu);
    }
}

class GamePanel extends JPanel implements ActionListener, KeyListener {
    private Timer timer;
    private int paddleX = 350;
    private int ballX = 400, ballY = 300;
    private int ballDirX = -2, ballDirY = -3;
    private final int PADDLE_WIDTH = 100, PADDLE_HEIGHT = 10;
    private final int BALL_DIAMETER = 20;
    private boolean[][] bricks;
    private final int BRICK_ROWS = 5, BRICK_COLS = 10;
    private final int BRICK_WIDTH = 70, BRICK_HEIGHT = 20;
    private int score = 0;

    private int paddleSpeed = 15; // Kecepatan dasar paddle

    public GamePanel() {
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        setBackground(Color.BLACK);
        initBricks();
        timer = new Timer(10, this);
        timer.start();
    }

    private void initBricks() {
        bricks = new boolean[BRICK_ROWS][BRICK_COLS];
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                bricks[i][j] = true; // Semua balok aktif
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Paddle
        g.setColor(Color.BLUE);
        g.fillRect(paddleX, getHeight() - 50, PADDLE_WIDTH, PADDLE_HEIGHT);

        // Bola
        g.setColor(Color.RED);
        g.fillOval(ballX, ballY, BALL_DIAMETER, BALL_DIAMETER);

        // Bricks
        g.setColor(Color.GREEN);
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                if (bricks[i][j]) {
                    g.fillRect(j * BRICK_WIDTH + 50, i * BRICK_HEIGHT + 50, BRICK_WIDTH - 5, BRICK_HEIGHT - 5);
                }
            }
        }

        // Skor
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 16));
        g.drawString("Score: " + score, 10, 20);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ballX += ballDirX;
        ballY += ballDirY;

        // Pantulan dari dinding
        if (ballX <= 0 || ballX >= getWidth() - BALL_DIAMETER) ballDirX *= -1;
        if (ballY <= 0) ballDirY *= -1;

        // Paddle collision
        if (ballY >= getHeight() - 50 - BALL_DIAMETER && ballX + BALL_DIAMETER >= paddleX && ballX <= paddleX + PADDLE_WIDTH) {
            ballDirY *= -1;
        }

        // Brick collision
        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLS; j++) {
                if (bricks[i][j]) {
                    int brickX = j * BRICK_WIDTH + 50;
                    int brickY = i * BRICK_HEIGHT + 50;

                    if (ballX + BALL_DIAMETER >= brickX && ballX <= brickX + BRICK_WIDTH &&
                        ballY + BALL_DIAMETER >= brickY && ballY <= brickY + BRICK_HEIGHT) {
                        bricks[i][j] = false;
                        ballDirY *= -1;
                        score += 10;
                    }
                }
            }
        }

        // Game over
        if (ballY > getHeight()) {
            timer.stop();
            int option = JOptionPane.showConfirmDialog(this, "Game Over! Your Score: " + score, "Game Over", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                restartGame();
            } else {
                System.exit(0);
            }
        }

        // Victory
        if (score == BRICK_ROWS * BRICK_COLS * 10) {
            timer.stop();
            int option = JOptionPane.showConfirmDialog(this, "You Win! Your Score: " + score, "Victory", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                restartGame();
            } else {
                System.exit(0);
            }
        }

        repaint();
    }

    private void restartGame() {
        score = 0;
        paddleX = 350;
        ballX = 400;
        ballY = 300;
        ballDirX = -2;
        ballDirY = -3;
        initBricks();
        timer.start();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT && paddleX > 0) {
            paddleX -= paddleSpeed;
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && paddleX < getWidth() - PADDLE_WIDTH) {
            paddleX += paddleSpeed;
        }

        // Jika tombol kiri atau kanan terus ditekan, kecepatan bisa ditambah
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            paddleSpeed = 30; // Kecepatan lebih tinggi saat ditekan terus
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            paddleSpeed = 30; // Kecepatan lebih tinggi saat ditekan terus
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        paddleSpeed = 15; // Mengembalikan kecepatan semula ketika tombol dilepaskan
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}
